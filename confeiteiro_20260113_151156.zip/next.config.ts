import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // SSR mode - compatible with Hostinger
  images: {
    unoptimized: true,
  },
};

export default nextConfig;

